﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;


namespace WpfApplication3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public class Data
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public string Description { get; set; }
        public string Amount { get; set; }
        
        public string EndofSubsription
        {
            get
            {
                return String.Format("the subsription will ative till{0}.",this.Date);
            }
        }
    }

    public class User
    {
        public string name { get; set; }
        public string acid { get; set; }
        public string email { get; set; }
        public string mobile { get; set; }
        public DateTime nextBillDate { get; set; }
        public string subFee { get; set; }
    }
    public partial class MainWindow : Window
    {
        //List<Data> rows = new List<Data>();
        ObservableCollection<Data> rows = new ObservableCollection<Data>();

        User user = new User();
        public MainWindow()
        {
            InitializeComponent();
            
            rows.Add(new Data() { Description = "Power pass subsription fee", Date = new DateTime(1971, 7, 23) , Amount = "$29.00" });
            rows.Add(new Data() { Description = "Power pass subsription fee", Date = new DateTime(1974, 1, 17), Amount = "$29.00" });
            rows.Add(new Data() { Description = "Power pass subsription fee", Date = new DateTime(1991, 9, 2), Amount = "$29.00" });
            dgUsers.ItemsSource = rows;
            EndofSubsriptionText.Text = EndofSubsription(rows[rows.Count - 1].Date);

            user.name = "Manish";
            user.email = "abc@gmail.com";
            user.mobile = "0000000000";
            user.nextBillDate = new DateTime(1991, 9, 2);
            user.subFee = "$500";
            user.acid = "##20000";

            this.DataContext = user;

            userName.Text = "Manish";
            acid.Text = "##20000";
            email.Content = "abc@gmail.com";
            mobile.Content = "00000000";
            nextBillingDate.Content = String.Format("{0:ddd, MMM d, yyyy}", new DateTime(1991, 9, 2));
            subscriptionFee.Content = "$500";

            Boolean isSubscriptionUser = true;
            if (isSubscriptionUser)
            {
                NONESUBSCRIPTION.Visibility = Visibility.Collapsed;
                SUBSCRIPTION.Visibility = Visibility.Visible;
            }else
            {

                NONESUBSCRIPTION.Visibility = Visibility.Visible;
                SUBSCRIPTION.Visibility = Visibility.Collapsed;
            }
        }

        public string EndofSubsription(DateTime lastDate)

        {
            return String.Format("the subsription will ative till "+ String.Format("{0:ddd, MMM d, yyyy}", lastDate));
        }

        private void load_More_Click(object sender, RoutedEventArgs e)
        {
            rows.Add(new Data() { Description = "Power pass subsription fee", Date = new DateTime(2000, 9, 11), Amount = "$29.00" });
            rows.Add(new Data() { Description = "Power pass subsription fee", Date = new DateTime(2001, 9, 12), Amount = "$29.00" });
            rows.Add(new Data() { Description = "Power pass subsription fee", Date = new DateTime(2002, 9, 13), Amount = "$29.00" });
            rows.Add(new Data() { Description = "Power pass subsription fee", Date = new DateTime(2003, 9, 14), Amount = "$29.00" });
            rows.Add(new Data() { Description = "Power pass subsription fee", Date = new DateTime(2004, 9, 15), Amount = "$29.00" });
            rows.Add(new Data() { Description = "Power pass subsription fee", Date = new DateTime(2005, 9, 16), Amount = "$29.00" });
            rows.Add(new Data() { Description = "Power pass subsription fee", Date = new DateTime(2006, 9, 17), Amount = "$29.00" });
            rows.Add(new Data() { Description = "Power pass subsription fee", Date = new DateTime(2007, 9, 18), Amount = "$29.00" });
            rows.Add(new Data() { Description = "Power pass subsription fee", Date = new DateTime(2008, 9, 19), Amount = "$29.00" });
            //dgUsers.ItemsSource = rows;
        }
    }
}
